
SET client_encoding = 'UTF8';



COMMENT ON SCHEMA public IS 'standard public schema';


ALTER SCHEMA public OWNER TO gpadmin;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM gpadmin;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO gpadmin;




CREATE TABLE public.heap_empty (
	a integer
) DISTRIBUTED BY (a);


ALTER TABLE public.heap_empty OWNER TO gpadmin;


CREATE TABLE public.ao_empty (
	a integer
) WITH (appendonly=true) DISTRIBUTED BY (a);


ALTER TABLE public.ao_empty OWNER TO gpadmin;


CREATE TABLE public.ao_full (
	a integer
) WITH (appendonly=true) DISTRIBUTED BY (a);


ALTER TABLE public.ao_full OWNER TO gpadmin;


CREATE TABLE public.repl_full (
	a integer
) DISTRIBUTED REPLICATED;


ALTER TABLE public.repl_full OWNER TO gpadmin;


CREATE TABLE public.heap_full (
	a integer
) DISTRIBUTED BY (a);


ALTER TABLE public.heap_full OWNER TO gpadmin;


CREATE TABLE public.aoco_empty (
	a integer ENCODING (compresstype=none,blocksize=32768,compresslevel=0),
	b text ENCODING (compresstype=none,blocksize=32768,compresslevel=0)
) WITH (appendonly=true, orientation=column) DISTRIBUTED BY (a);


ALTER TABLE public.aoco_empty OWNER TO gpadmin;


CREATE TABLE public.repl_empty (
	a integer
) DISTRIBUTED REPLICATED;


ALTER TABLE public.repl_empty OWNER TO gpadmin;


CREATE TABLE public.skip_part (
	id integer,
	d integer
) DISTRIBUTED BY (id) PARTITION BY RANGE(d) 
          (
          START (0) END (10) EVERY (10) WITH (tablename='skip_part_1_prt_1', appendonly='false'), 
          START (10) END (20) EVERY (10) WITH (tablename='skip_part_1_prt_2', appendonly='false'), 
          START (20) END (30) EVERY (10) WITH (tablename='skip_part_1_prt_3', appendonly='false'), 
          START (30) END (40) EVERY (10) WITH (tablename='skip_part_1_prt_4', appendonly='false')
          );


ALTER TABLE public.skip_part OWNER TO gpadmin;
