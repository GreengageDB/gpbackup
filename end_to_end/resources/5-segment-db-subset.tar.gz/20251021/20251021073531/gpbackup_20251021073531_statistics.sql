
SET client_encoding = 'UTF8';


UPDATE pg_class
SET
	relpages = 1::int,
	reltuples = 1.000000::real
WHERE oid = 'gpadmin.d'::regclass::oid;


UPDATE pg_class
SET
	relpages = 1::int,
	reltuples = 1.000000::real
WHERE oid = 'gpadmin.r'::regclass::oid;


DELETE FROM pg_statistic WHERE (starelid, staattnum) =
	(SELECT attrelid, attnum FROM pg_attribute WHERE attrelid = 'gpadmin.d'::regclass::oid AND attname = 'i');


INSERT INTO pg_statistic SELECT
	attrelid,
	attnum,
	false::boolean,
	0.000000::real,
	4::integer,
	-1.000000::real,
	0::smallint,
	0::smallint,
	0::smallint,
	0::smallint,
	0::smallint,
	0::oid,
	0::oid,
	0::oid,
	0::oid,
	0::oid,
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
FROM pg_attribute WHERE attrelid = 'gpadmin.d'::regclass::oid AND attname = 'i';


DELETE FROM pg_statistic WHERE (starelid, staattnum) =
	(SELECT attrelid, attnum FROM pg_attribute WHERE attrelid = 'gpadmin.r'::regclass::oid AND attname = 'c');


INSERT INTO pg_statistic SELECT
	attrelid,
	attnum,
	false::boolean,
	0.000000::real,
	5::integer,
	-1.000000::real,
	0::smallint,
	0::smallint,
	0::smallint,
	0::smallint,
	0::smallint,
	0::oid,
	0::oid,
	0::oid,
	0::oid,
	0::oid,
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL::real[],
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
FROM pg_attribute WHERE attrelid = 'gpadmin.r'::regclass::oid AND attname = 'c';
