
SET client_encoding = 'UTF8';


ALTER RESOURCE QUEUE pg_default WITH (ACTIVE_STATEMENTS=20);

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 0;

ALTER RESOURCE GROUP default_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP default_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP default_group SET CONCURRENCY 20;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 30;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 10;

ALTER RESOURCE GROUP admin_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP admin_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP admin_group SET CONCURRENCY 10;

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 10;

CREATE ROLE gpadmin;
ALTER ROLE gpadmin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION PASSWORD 'md5b44a9b06d576a0b083cd60e5f875cf48' RESOURCE QUEUE pg_default RESOURCE GROUP admin_group CREATEEXTTABLE (protocol='http') CREATEEXTTABLE (protocol='gpfdist', type='readable') CREATEEXTTABLE (protocol='gpfdist', type='writable');



CREATE DATABASE testdb TEMPLATE template0;

ALTER DATABASE testdb OWNER TO gpadmin;



COMMENT ON SCHEMA public IS 'standard public schema';


ALTER SCHEMA public OWNER TO gpadmin;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM gpadmin;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO gpadmin;


CREATE SCHEMA schemaone;

ALTER SCHEMA schemaone OWNER TO gpadmin;


CREATE SCHEMA schematwo;

ALTER SCHEMA schematwo OWNER TO gpadmin;




CREATE TABLE schemaone.tablefour (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tablefour OWNER TO gpadmin;


CREATE TABLE schematwo.tablefour (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tablefour OWNER TO gpadmin;


CREATE TABLE schemaone.tabletwo (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tabletwo OWNER TO gpadmin;


CREATE TABLE schemaone.tablethree (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tablethree OWNER TO gpadmin;


CREATE TABLE schematwo.tabletwo (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tabletwo OWNER TO gpadmin;


CREATE TABLE schematwo.tablethree (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tablethree OWNER TO gpadmin;


CREATE TABLE schemaone.tableone (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tableone OWNER TO gpadmin;


CREATE TABLE schematwo.tableone (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tableone OWNER TO gpadmin;
